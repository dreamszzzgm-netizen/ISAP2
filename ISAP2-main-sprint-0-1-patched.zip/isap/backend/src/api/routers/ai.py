"""AI service health endpoints."""
from fastapi import APIRouter

from src.core.settings import settings
from src.infrastructure.llm.providers import LLMMessage, get_llm_provider

router = APIRouter()


@router.get("/health")
async def ai_health() -> dict:
    """Check configured LLM provider without exposing secrets."""
    provider = get_llm_provider()
    try:
        response = await provider.complete(
            [LLMMessage(role="user", content="Ответь одним словом: ok")],
            temperature=0.0,
            max_tokens=16,
        )
        return {
            "status": "ok",
            "provider": settings.llm_provider,
            "model": response.model,
        }
    except Exception as exc:
        return {
            "status": "error",
            "provider": settings.llm_provider,
            "error": exc.__class__.__name__,
            "message": str(exc),
        }
